import random
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from datetime import datetime
import plivo



from paho.mqtt import client as mqtt_client


client2 = plivo.RestClient('MAZDQ4NDQYZJA4MMU5MM','MDU2YTY0M2IzNTQ4MDFjOTQ0OGEwYzY2MzE1YjY5')

cred = credentials.Certificate('innovasjonsprosjekt-ccba7-firebase-adminsdk-mwb4h-01e2310ba5.json')

firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://innovasjonsprosjekt-ccba7-default-rtdb.europe-west1.firebasedatabase.app/'


})

broker = 'mqtt.eclipseprojects.io'
port = 1883
topic = "my/publish/topic"
# generate client ID with pub prefix randomly
client_id = 'myid_123'
username = 'alexmj044'
password = 'public'
previous1=100

def connect_mqtt() -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client(client_id)
    client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def subscribe(client: mqtt_client):
    def on_message(client, userdata, msg):
        ref2 = db.reference('/Measurement')

        dataM=ref2.get()
        lastTime=list((dataM.keys()))[-1]
        lastM=dataM[lastTime]

        print(f"Received `{msg.payload.decode()}` from `{msg.topic}` topic")
        now = datetime.now()

        if(int(msg.payload.decode()[-3:])<int(lastM)-30):
            ref3=db.reference('/Number')
            dataN=ref3.get()
            nList=list(dataN.keys())
            
            response = client2.messages.create(
                src='TATATATAA',
                dst="+4795555608",
                text='Nå er det brøytet!',)
            print(response)
            
        dt_string = now.strftime("%H:%M:%S")
        ref = db.reference('/Measurement')
        ref.update({
            dt_string: msg.payload.decode()[-3:]
        })
    client.subscribe(topic)
    client.on_message = on_message


def run():
    client = connect_mqtt()
    subscribe(client)
    client.loop_forever()


if __name__ == '__main__':
    run()
